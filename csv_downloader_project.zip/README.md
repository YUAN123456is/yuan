# CSV Data Downloader

A web-based application that allows users to select a date and download data from an API in CSV format.

## Features

- Date selection using a calendar interface
- API data retrieval based on selected date
- Automatic CSV file generation and download
- User-friendly feedback with loading, success, and error states

## How to Use

1. Select a date using the date picker
2. Click the "Download CSV" button
3. The CSV file will be automatically downloaded to your device

## Technical Details

- Built with Flask (Python)
- Uses Bootstrap for responsive UI
- Fetches data from adtechapi.com