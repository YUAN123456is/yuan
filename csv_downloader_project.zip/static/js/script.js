document.addEventListener('DOMContentLoaded', function() {
    // Initialize date picker
    const datePicker = flatpickr("#datePicker", {
        dateFormat: "Y-m-d",
        maxDate: "today",
        defaultDate: "today",
        altInput: true,
        altFormat: "F j, Y",
        allowInput: true
    });
    
    // References to elements
    const downloadForm = document.getElementById('downloadForm');
    const downloadBtn = document.getElementById('downloadBtn');
    const loadingAlert = document.getElementById('loadingAlert');
    const errorAlert = document.getElementById('errorAlert');
    const errorMessage = document.getElementById('errorMessage');
    const successAlert = document.getElementById('successAlert');
    const successMessage = document.getElementById('successMessage');
    
    // Handle form submission
    downloadForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        // Get the selected date
        const selectedDate = document.getElementById('datePicker').value;
        
        if (!selectedDate) {
            showError('Please select a date first.');
            return;
        }
        
        // Show loading state
        showLoading(true);
        
        try {
            // Make API request
            const response = await fetch('/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ date: selectedDate }),
            });
            
            // Check if the request was successful
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to download data');
            }
            
            // Get the blob from the response
            const blob = await response.blob();
            
            // Create a URL for the blob
            const downloadUrl = window.URL.createObjectURL(blob);
            
            // Create a temporary link and click it to download the file
            const downloadLink = document.createElement('a');
            downloadLink.href = downloadUrl;
            downloadLink.download = `data_${selectedDate}.csv`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            
            // Clean up
            document.body.removeChild(downloadLink);
            window.URL.revokeObjectURL(downloadUrl);
            
            // Show success message
            showSuccess(`Data for ${selectedDate} downloaded successfully.`);
        } catch (error) {
            // Show error message
            showError(error.message || 'An error occurred while downloading the data.');
            console.error('Download error:', error);
        } finally {
            // Hide loading state
            showLoading(false);
        }
    });
    
    // Helper function to show loading state
    function showLoading(isLoading) {
        if (isLoading) {
            downloadBtn.disabled = true;
            loadingAlert.classList.remove('d-none');
            errorAlert.classList.add('d-none');
            successAlert.classList.add('d-none');
        } else {
            downloadBtn.disabled = false;
            loadingAlert.classList.add('d-none');
        }
    }
    
    // Helper function to show error message
    function showError(message) {
        errorMessage.textContent = message;
        errorAlert.classList.remove('d-none');
        successAlert.classList.add('d-none');
        loadingAlert.classList.add('d-none');
    }
    
    // Helper function to show success message
    function showSuccess(message) {
        successMessage.textContent = message;
        successAlert.classList.remove('d-none');
        errorAlert.classList.add('d-none');
        loadingAlert.classList.add('d-none');
    }
});
