import os
import csv
import io
import requests
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

@app.route('/')
def index():
    """Render the home page with date picker."""
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download_csv():
    """
    Fetch data from the API based on the selected date and return a CSV file.
    """
    try:
        data_date = request.json.get('date')
        logger.debug(f"Received date: {data_date}")
        
        if not data_date:
            return jsonify({"error": "Date is required"}), 400
        
        # API parameters
        security_key = "j09LluJ91f12n1VK"  # This would ideally come from environment variables
        limit = 30000
        page = 1
        
        # Fetch data from API
        data = fetch_data(security_key, data_date, limit, page)
        
        if not data or not isinstance(data, list) or len(data) == 0:
            return jsonify({"error": "No data received from API"}), 404
        
        # Generate CSV in memory
        csv_data = generate_csv_in_memory(data)
        
        # Prepare the response with the CSV file
        mem = io.BytesIO()
        mem.write(csv_data.getvalue().encode('utf-8'))
        mem.seek(0)
        
        # Format filename with the selected date
        filename = f"data_{data_date}.csv"
        
        logger.debug(f"Sending file: {filename}")
        return send_file(
            mem,
            mimetype='text/csv',
            download_name=filename,
            as_attachment=True
        )
        
    except Exception as e:
        logger.error(f"Error processing download: {str(e)}")
        return jsonify({"error": str(e)}), 500

def fetch_data(security_key, data_date, limit, page):
    """
    Fetch data from the API
    """
    url = (
        f"https://adtechapi.com/v2/google/reportDataSource?"
        f"security_key={security_key}&data_date={data_date}&limit={limit}&page={page}"
    )
    
    logger.debug(f"Fetching data from URL: {url}")
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        logger.debug("API response received")
        
        if 'data' not in data or 'list' not in data['data']:
            logger.error("API response format is not as expected: missing 'data' or 'list' fields")
            raise ValueError("API response format is not as expected")
        
        return data['data']['list']
    except Exception as e:
        logger.error(f"Failed to fetch data: {str(e)}")
        raise

def generate_csv_in_memory(data):
    """
    Generate a CSV file in memory from the data list
    """
    logger.debug("Generating CSV in memory")
    
    # Create a StringIO object to write CSV data to memory
    output = io.StringIO()
    
    # Extract headers from the first item in the data list
    if data and len(data) > 0:
        keys = list(data[0].keys())
        
        # Write data to CSV
        writer = csv.writer(output)
        writer.writerow(keys)  # Write headers
        
        for item in data:
            writer.writerow([item.get(key, "") for key in keys])
    
    return output

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
